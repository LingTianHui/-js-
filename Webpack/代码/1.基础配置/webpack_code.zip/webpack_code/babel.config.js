module.exports = {
  // 智能预设：能够编译ES6语法
  presets: ["@babel/preset-env"],
};
