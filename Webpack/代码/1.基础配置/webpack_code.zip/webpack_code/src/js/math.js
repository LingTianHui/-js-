export function add(x, y) {
  return x + y;
}

export function mul(x, y) {
  return x * y;
}
