<template>
  <div class="video-container">视频</div>
</template>

<script>
export default {
  name: 'VideoIndex',
  components: {},
  props: {},
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {},
  mounted () {},
  methods: {}
}
</script>

<style scoped lang="less"></style>
